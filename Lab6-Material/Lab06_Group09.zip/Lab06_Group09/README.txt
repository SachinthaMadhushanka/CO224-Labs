* Compile and Run Lab06_Group09.v
    Compile : iverilog -o Lab06_Group09.vvp Lab06_Group09.v
    Run     : vvp Lab06_Group09.vvp

* Lab-06 Part-2 Completed.
* Data Memory Cache module is connected to CPU.
* Instruction Register is yet to implemented properly. For now it takes instruction as input and returns the same instruction.